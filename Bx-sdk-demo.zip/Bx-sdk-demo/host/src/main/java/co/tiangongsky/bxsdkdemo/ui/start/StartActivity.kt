package co.tiangongsky.bxsdkdemo.ui.start

import co.bxvip.android.commonlib.utils.CommonInit.ctx
import co.bxvip.sdk.ui.BxStartActivityImpl
import com.qihoo360.replugin.RePlugin

class StartActivity : BxStartActivityImpl() {
    override fun toYourMainActivity() {
        // 跳到主页 demo
        val startActivity = RePlugin.startActivity(ctx,
                RePlugin.createIntent("com.tiangong.android.plugin.demo",
                        "com.tiangong.android.plugin.demo.MainActivity"))
        if (startActivity) {
            finish()
        } else {
            println("进入app失败！")
        }
        finish()
    }
}
