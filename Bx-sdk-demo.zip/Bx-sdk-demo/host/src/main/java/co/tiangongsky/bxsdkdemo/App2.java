package co.tiangongsky.bxsdkdemo;


import cn.jpush.android.api.JPushInterface;
import co.bxvip.sdk.BxRePluginAppLicationMakeImpl;
import cn.jpush.android.api.CustomPushNotificationBuilder;

public class App2 extends BxRePluginAppLicationMakeImpl {
    @Override
    public void initJPushYouNeed() {
        JPushInterface.setDebugMode(BuildConfig.DEBUG);    // 设置开启日志,发布时请关闭日志
        JPushInterface.init(this);                         // 初始化 JPush
        CustomPushNotificationBuilder builder = new CustomPushNotificationBuilder(this, R.layout.customer_notitfication_layout, R.id.icon, R.id.title, R.id.text);
        builder.layoutIconDrawable = R.mipmap.logo;
        builder.developerArg0 = "developerArg2";
        JPushInterface.setDefaultPushNotificationBuilder(builder);
    }

    @Override
    public void initRePluginYourNeed() {

    }

    @Override
    public void onCreate() {
        super.onCreate();
//        x.Ext.init(this);
//        x.Ext.setDebug(true);
//
//        String packageName = getPackageName();
//        Toast.makeText(this,packageName,Toast.LENGTH_LONG).show();
//        LogUtil.e("dddddddddddd"+packageName);
    }

//    public  String getPackageName2() {
//        try {
//            PackageInfo packageInfo = x.app().getPackageManager().getPackageInfo(x.app().getPackageName(), 0);
//            return packageInfo.packageName;
//        } catch (PackageManager.NameNotFoundException e) {
//            e.printStackTrace();
//            return "";
//        }
//    }

}
